package ChunkSize.ChunkSize;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChunkSizeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChunkSizeApplication.class, args);
	}

}
