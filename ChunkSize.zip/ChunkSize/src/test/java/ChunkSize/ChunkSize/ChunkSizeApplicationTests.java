package ChunkSize.ChunkSize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChunkSizeApplicationTests {

	@Test
	void contextLoads() {
	}

}
